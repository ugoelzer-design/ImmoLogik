export type Kostenart = {
  id: string;
  name: string;
  kategorie: string;
  umlagefaehigMieter: boolean;
  umlagefaehigVermieter: boolean;
  standardSchluessel: string;
  messartRef?: string;
  aktivDefault: boolean;
};

export const kostenarten: Kostenart[] = [
  { id: "KA_001", name: "Allgemeine Reparaturen",          kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: true  },
  { id: "KA_002", name: "Allgemeinstrom",                  kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "Personen", aktivDefault: true  },
  { id: "KA_003", name: "Aufzugswartung",                  kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_004", name: "Bankgebühren",                    kategorie: "Betrieb",    umlagefaehigMieter: false, umlagefaehigVermieter: false, standardSchluessel: "MEA",      aktivDefault: true  },
  { id: "KA_005", name: "Beleuchtung Außenanlagen",        kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_006", name: "Gartenpflege",                    kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_007", name: "Gebäudeversicherung",             kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: true  },
  { id: "KA_008", name: "Gemeinschaftsantenne / Kabel",    kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_009", name: "Haftpflichtversicherung",         kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_010", name: "Hausmeister",                     kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_011", name: "Hausreinigung",                   kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_012", name: "Heizung",                         kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "Verbrauch", messartRef: "HEIZUNG", aktivDefault: true },
  { id: "KA_013", name: "Heizungswartung",                 kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: true  },
  { id: "KA_014", name: "Messdienst / Ablesung",           kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "Verbrauch", aktivDefault: false },
  { id: "KA_015", name: "Müllentsorgung",                  kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "Personen", aktivDefault: true  },
  { id: "KA_016", name: "Prüfkosten (Rauchmelder etc.)",   kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_017", name: "Rechts- und Beratungskosten",     kategorie: "Betrieb",    umlagefaehigMieter: false, umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_018", name: "Sachverständigenkosten",          kategorie: "Betrieb",    umlagefaehigMieter: false, umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_019", name: "Schornsteinfeger",                kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: true  },
  { id: "KA_020", name: "Sonstige Betriebskosten",         kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_021", name: "Straßenreinigung",                kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_022", name: "Tiefgarage",                      kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_023", name: "Verwalterkosten",                 kategorie: "Betrieb",    umlagefaehigMieter: false, umlagefaehigVermieter: false, standardSchluessel: "MEA",      aktivDefault: true  },
  { id: "KA_024", name: "Wasser/Abwasser Allgemein",       kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "Verbrauch", messartRef: "WASSER", aktivDefault: true },
  { id: "KA_025", name: "Winterdienst",                    kategorie: "Betrieb",    umlagefaehigMieter: true,  umlagefaehigVermieter: true,  standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_201", name: "Entnahme Instandhaltungsrücklage", kategorie: "Rücklage",  umlagefaehigMieter: false, umlagefaehigVermieter: false, standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_202", name: "Zuführung Instandhaltungsrücklage", kategorie: "Rücklage", umlagefaehigMieter: false, umlagefaehigVermieter: false, standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_301", name: "Kosten aus Sonderabrechnung",     kategorie: "Sonderfall", umlagefaehigMieter: false, umlagefaehigVermieter: false, standardSchluessel: "MEA",      aktivDefault: false },
  { id: "KA_302", name: "Sonderumlage",                    kategorie: "Sonderfall", umlagefaehigMieter: false, umlagefaehigVermieter: false, standardSchluessel: "MEA",      aktivDefault: false },
];

export const standardKostenarten = kostenarten.filter((k) => k.aktivDefault);
export const optionaleKostenarten = kostenarten.filter((k) => !k.aktivDefault);

export function getKostenartenFuerWEG(aktivIds?: string[]): Kostenart[] {
  if (!aktivIds || aktivIds.length === 0) return standardKostenarten;
  return kostenarten.filter((k) => aktivIds.includes(k.id));
}

export function initialKostenartenFuerNeueWEG(): string[] {
  return standardKostenarten.map((k) => k.id);
}