export class CreateContractDto {
  objectId!: string;
  tenantId!: string;
  rentUnitId?: string | null;
  title!: string;
  startDate!: string;
  endDate!: string;
  status?: string;
}
