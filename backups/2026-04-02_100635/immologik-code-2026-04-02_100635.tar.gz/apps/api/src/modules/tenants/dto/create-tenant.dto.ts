export class CreateTenantDto {
  objectId!: string;
  rentUnitId!: string;
  fullName!: string;
  email!: string;
  phone!: string;
  status?: string;
}
