import { BadRequestException, NotFoundException } from "@nestjs/common";
import { DocumentsService } from "./documents.service";

describe("DocumentsService", () => {
  let service: DocumentsService;
  let prisma: {
    document: {
      findMany: jest.Mock;
      findUnique: jest.Mock;
      create: jest.Mock;
      update: jest.Mock;
      delete: jest.Mock;
    };
  };
  let minio: {
    uploadFile: jest.Mock;
    getPresignedUrl: jest.Mock;
    deleteFile: jest.Mock;
  };

  beforeEach(() => {
    prisma = {
      document: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
      },
    };
    minio = {
      uploadFile: jest.fn(),
      getPresignedUrl: jest.fn(),
      deleteFile: jest.fn(),
    };

    service = new DocumentsService(prisma as never, minio as never);
  });

  it("maps documents to API shape with ISO dates and defaults", async () => {
    prisma.document.findMany.mockResolvedValueOnce([
      {
        id: "doc-1",
        title: "Beleg",
        fileName: "beleg.pdf",
        mimeType: "application/pdf",
        size: 123,
        storageKey: "docs/beleg.pdf",
        objectId: null,
        objectName: null,
        rentUnitId: null,
        unitLabel: null,
        reportYear: null,
        category: null,
        status: null,
        uploadedBy: null,
        createdAt: new Date("2026-03-22T10:00:00.000Z"),
        updatedAt: new Date("2026-03-22T11:00:00.000Z"),
      },
    ]);
    minio.getPresignedUrl.mockResolvedValueOnce("https://download.test/doc-1");

    const result = await service.findAll();

    expect(result).toEqual([
      {
        id: "doc-1",
        title: "Beleg",
        fileName: "beleg.pdf",
        mimeType: "application/pdf",
        size: 123,
        objectId: null,
        objectName: "Allgemein",
        rentUnitId: null,
        unitLabel: null,
        reportYear: null,
        category: "Sonstiges",
        status: "Vorhanden",
        uploadedBy: null,
        downloadUrl: "https://download.test/doc-1",
        createdAt: "2026-03-22T10:00:00.000Z",
        updatedAt: "2026-03-22T11:00:00.000Z",
      },
    ]);
  });

  it("uploads a document and persists metadata", async () => {
    jest.spyOn(Date, "now").mockReturnValue(1710000000000);
    minio.getPresignedUrl.mockResolvedValueOnce("https://download.test/uploaded");
    prisma.document.create.mockResolvedValueOnce({
      id: "doc-2",
      title: "Vertrag",
      fileName: "vertrag.pdf",
      mimeType: "application/pdf",
      size: 456,
      storageKey: "wegs/object-1/wohnungen/unit-7/historie/2025/Mietvertrag/1710000000000_vertrag.pdf",
      objectId: "object-1",
      objectName: "WEG-001 · Musterhaus",
      rentUnitId: "unit-7",
      unitLabel: "WE 07",
      reportYear: 2025,
      category: "Mietvertrag",
      status: "Vorhanden",
      uploadedBy: "Tester",
      createdAt: new Date("2026-03-22T12:00:00.000Z"),
      updatedAt: new Date("2026-03-22T12:00:00.000Z"),
    });

    const file = {
      originalname: "vertrag.pdf",
      mimetype: "application/pdf",
      size: 456,
      buffer: Buffer.from("pdf"),
    } as Express.Multer.File;

    const result = await service.upload(
      file,
      "object-1",
      "WEG-001 · Musterhaus",
      "unit-7",
      "WE 07",
      "2025",
      "Mietvertrag",
      "Vertrag",
      "Tester",
    );

    expect(minio.uploadFile).toHaveBeenCalledWith(
      "wegs/object-1/wohnungen/unit-7/historie/2025/Mietvertrag/1710000000000_vertrag.pdf",
      file.buffer,
      "application/pdf",
      {
        "x-category": "Mietvertrag",
        "x-object-id": "object-1",
        "x-rent-unit-id": "unit-7",
        "x-report-year": "2025",
      },
    );
    expect(prisma.document.create).toHaveBeenCalled();
    expect(result.downloadUrl).toBe("https://download.test/uploaded");

    jest.restoreAllMocks();
  });

  it("throws when requesting a missing document", async () => {
    prisma.document.findUnique.mockResolvedValueOnce(null);

    await expect(service.findOne("missing")).rejects.toBeInstanceOf(NotFoundException);
  });

  it("requires a report year for annual reports and utility statements", async () => {
    const file = {
      originalname: "report.pdf",
      mimetype: "application/pdf",
      size: 100,
      buffer: Buffer.from("pdf"),
    } as Express.Multer.File;

    await expect(
      service.upload(file, "object-1", "WEG-001 · Musterhaus", undefined, undefined, "", "Jahresreport WEG", "Jahresreport WEG", "Tester"),
    ).rejects.toBeInstanceOf(BadRequestException);
  });
});
