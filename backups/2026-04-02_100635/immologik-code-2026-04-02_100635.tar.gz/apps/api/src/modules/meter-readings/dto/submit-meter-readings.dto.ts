export class SubmitMeterReadingItemDto {
  meterId!: string;
  value!: number;
  date?: string;
}

export class SubmitMeterReadingsDto {
  readerName?: string;
  readings!: SubmitMeterReadingItemDto[];
}
