import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { CreateReadingCampaignDto } from './dto/create-reading-campaign.dto';
import { SubmitMeterReadingsDto } from './dto/submit-meter-readings.dto';
import { MeterReadingsService } from './meter-readings.service';

@Controller('meter-readings')
export class MeterReadingsController {
  constructor(private readonly meterReadingsService: MeterReadingsService) {}

  @Get('campaigns')
  findCampaigns(@Query('objectId') objectId?: string) {
    return this.meterReadingsService.findCampaigns(objectId);
  }

  @Post('campaigns')
  createCampaign(@Body() dto: CreateReadingCampaignDto) {
    return this.meterReadingsService.createCampaign(dto);
  }

  @Get('access/:token')
  getAccess(@Param('token') token: string) {
    return this.meterReadingsService.getAccess(token);
  }

  @Post('access/:token/readings')
  submitReadings(@Param('token') token: string, @Body() dto: SubmitMeterReadingsDto) {
    return this.meterReadingsService.submitReadings(token, dto);
  }
}
