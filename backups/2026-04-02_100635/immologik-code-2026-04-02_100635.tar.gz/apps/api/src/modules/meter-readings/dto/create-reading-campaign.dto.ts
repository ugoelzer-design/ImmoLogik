export class CreateReadingCampaignDto {
  objectId!: string;
  reportYear!: number;
  expiresAt?: string;
}
